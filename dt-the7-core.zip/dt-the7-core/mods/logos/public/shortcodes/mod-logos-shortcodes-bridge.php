<?php

// File Security Check.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

vc_lean_map( 'dt_logos', null, dirname( __FILE__ ) . '/mod-logos-vc-bridge.php' );
