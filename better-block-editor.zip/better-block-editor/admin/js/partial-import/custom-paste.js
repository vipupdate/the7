/**
 * WordPress Block Editor Paste Handler
 * Implementation using reliable WordPress hooks and APIs
 */
(function (wp) {
    const {addFilter} = wp.hooks;
    const {select, dispatch, subscribe} = wp.data;
    const {createBlock} = wp.blocks;
    const {pasteHandler, serialize} = wp.blocks;
    const stripHTML = wp.dom.__unstableStripHTML;
    const {apiFetch} = wp;

    // Configuration constants
    const BATCH_SIZE = parseInt(window.customPasteConfig?.batchSize || 3); // Maximum number of images to process in a single request

    /**
     * Recursively traverses blocks and their innerBlocks, applying a callback to each block
     *
     * @param {Array} blocks - Array of blocks to traverse
     * @param {Function} callback - Function to call on each block
     * @param {boolean} isAsync - Whether the callback is async or not
     * @return {Array|Promise<Array>} - The processed blocks or a Promise resolving to processed blocks
     */
    const traverseBlocks = (blocks, callback, isAsync = false) => {
        if (!blocks || !blocks.length) return isAsync ? Promise.resolve(blocks) : blocks;

        // For async callbacks, we need to gather promises and resolve them
        if (isAsync) {
            // Create an array of promises for each block
            const promises = blocks.map(async (block) => {
                // Process innerBlocks first (if they exist)
                if (block.innerBlocks && block.innerBlocks.length) {
                    const processedInnerBlocks = await traverseBlocks(block.innerBlocks, callback, true);
                    block = {
                        ...block,
                        innerBlocks: processedInnerBlocks
                    };
                }

                // Apply callback to the current block
                return await callback(block);
            });

            // Return a promise that resolves when all blocks are processed
            return Promise.all(promises);
        }

        // For synchronous callbacks, process immediately
        return blocks.map(block => {
            // Process innerBlocks recursively if they exist
            if (block.innerBlocks && block.innerBlocks.length) {
                return {
                    ...block,
                    innerBlocks: traverseBlocks(block.innerBlocks, callback)
                };
            }

            return callback(block);
        });
    };

    /**
     * Process multiple image URLs in a single batch request
     * This reduces HTTP requests when pasting content with multiple images
     *
     * @param {Array} imageUrls - Array of image URLs to process
     * @return {Promise<Object>} - Object mapping original URLs to processed image data
     */
    const batchProcessImages = async (imageUrls) => {
        debugInfo.imageStats.total += imageUrls.length;
        debugInfo.time('🔄 Batch processing images');

        // Filter out URLs that we already have in cache
        const urlsToProcess = imageUrls;

        debugInfo.log(`⬇️ Processing ${urlsToProcess.length} new images, ${imageUrls.length - urlsToProcess.length} from cache`);
        debugInfo.imageStats.fromCache += (imageUrls.length - urlsToProcess.length);

        // Split the URLs into smaller batches to prevent timeouts
        const results = {};
        let successfullyProcessed = 0;
        let cachedFromServer = 0;
        let failedToProcess = 0;

        // Process in batches of BATCH_SIZE
        for (let i = 0; i < urlsToProcess.length; i += BATCH_SIZE) {
            const batchUrls = urlsToProcess.slice(i, i + BATCH_SIZE);
            debugInfo.imageStats.batchesProcessed++;
            debugInfo.log(`  🔄 Processing batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(urlsToProcess.length / BATCH_SIZE)} (${batchUrls.length} images)`);

            try {
                // Create form data for the AJAX request
                const formData = new FormData();
                formData.append('action', 'custom_paste_download_image_batch');
                formData.append('image_urls', JSON.stringify(batchUrls));
                formData.append('nonce', customPasteConfig.nonce);

                // Make a request to the WordPress AJAX endpoint
                debugInfo.time(`  ↪ AJAX request (batch ${Math.floor(i / BATCH_SIZE) + 1})`);
                const response = await fetch(customPasteConfig.ajax_url, {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: formData
                });
                debugInfo.timeEnd(`  ↪ AJAX request (batch ${Math.floor(i / BATCH_SIZE) + 1})`);

                if (!response.ok) {
                    throw new Error(`Failed to process batch: ${response.statusText}`);
                }

                const responseData = await response.json();

                if (!responseData.success) {
                    throw new Error('WordPress failed to process batch');
                }

                // Update cache with the new images
                let batchCachedFromServer = 0;

                // Handle the new response structure
                const responseImages = responseData.data.data || responseData.data;

                Object.entries(responseImages).forEach(([originalUrl, imageData]) => {
                    results[originalUrl] = imageData;

                    // Track if image was already in server cache
                    if (imageData.from_cache) {
                        batchCachedFromServer++;
                    }
                });

                const batchNewlyDownloaded = batchUrls.length - batchCachedFromServer;
                successfullyProcessed += batchUrls.length;
                cachedFromServer += batchCachedFromServer;

                debugInfo.imageStats.newlyDownloaded += batchNewlyDownloaded;
                debugInfo.log(`    ✓ Batch ${Math.floor(i / BATCH_SIZE) + 1} complete: ${batchUrls.length} images processed (${batchCachedFromServer} from server cache)`);



            } catch (error) {
                debugInfo.log(`    ❌ Error processing batch ${Math.floor(i / BATCH_SIZE) + 1}:`, error);
                failedToProcess += batchUrls.length;
                debugInfo.imageStats.failed += batchUrls.length;

                // For failed batches, use original URLs
                batchUrls.forEach(url => {
                    results[url] = {
                        id: null,
                        url: url,
                        alt: '',
                        caption: ''
                    };
                });
            }

            // Add a small delay between batches to prevent overloading the server
            if (i + BATCH_SIZE < urlsToProcess.length) {
                await new Promise(resolve => setTimeout(resolve, 300));
            }
        }

        debugInfo.log(`  ⚡ Batch processing complete: ${successfullyProcessed} successful, ${cachedFromServer} from server cache, ${failedToProcess} failed`);
        debugInfo.timeEnd('🔄 Batch processing images');

        return results;
    };

    /**
     * The most reliable approach: Direct DOM paste event handling
     * This gives complete control over the pasted content before WordPress processes it
     */
    wp.domReady(() => {

        // Process pasted content before it's inserted
        const processPastedContent = async (html) => {
            debugInfo.time('⚡ Processing pasted content');
            debugInfo.resetStats();
            debugInfo.log('Processing pasted HTML:', html.substring(0, 100) + (html.length > 100 ? '...' : ''));

            // Parse HTML into blocks
            const blocks = pasteHandler({HTML: html});

            // Find image blocks and log their IDs and sources
            if (blocks && blocks.length) {
                debugInfo.log(`Found ${blocks.length} blocks in pasted content`);

                // First pass: Collect all image URLs that need processing
                const imageUrls = [];
                const collectImageUrls = (block) => {
                    if (block.name === 'core/image' || block.name === 'core/cover') {
                        if (block.attributes.url && !block.attributes.url.includes(window.customPasteSiteUrl)) {
                            imageUrls.push(block.attributes.url);
                        }
                    }

                    // Check for background images
                    const background = block.attributes?.style?.background?.backgroundImage;
                    if (background && background.url && !background.url.includes(window.customPasteSiteUrl)) {
                        imageUrls.push(background.url);
                    }

                    // Check the7-blocks svg
                    if (block.attributes?.imageURL) {
                        imageUrls.push(block.attributes.imageURL);
                    }

                    return block;
                };

                // Collect all image URLs from blocks
                debugInfo.time('  ↪ Collecting image URLs');
                await traverseBlocks(blocks, collectImageUrls);
                debugInfo.timeEnd('  ↪ Collecting image URLs');

                // Process all unique image URLs in a single batch if we have any
                let processedImages = {};
                if (imageUrls.length > 0) {
                    // Remove duplicates
                    const uniqueImageUrls = [...new Set(imageUrls)];
                    debugInfo.log(`Found ${uniqueImageUrls.length} unique external images to process (${imageUrls.length - uniqueImageUrls.length} duplicates)`);
                    processedImages = await batchProcessImages(uniqueImageUrls);
                }
                // Second pass: Update blocks with processed images
                debugInfo.time('  ↪ Updating blocks with processed images');
                const processedBlocks = await traverseBlocks(blocks, async (block) => {
                    let editedBlock = block;

                    // Process image blocks
                    if ((block.name === 'core/image' || block.name === 'core/cover') &&
                        block.attributes.url && !block.attributes.url.includes(window.customPasteSiteUrl)) {
                        const imageUrl = block.attributes.url;
                        if (processedImages[imageUrl]) {
                            const imageData = processedImages[imageUrl];
                            editedBlock.attributes.url = imageData.url;
                            editedBlock.attributes.id = imageData.id;
                            if (imageData.alt) {
                                editedBlock.attributes.alt = imageData.alt;
                            }
                            if (imageData.caption) {
                                editedBlock.attributes.caption = imageData.caption;
                            }
                        }
                    }

                    // Process background images
                    const background = block.attributes?.style?.background?.backgroundImage;
                    if (background && background.url && !background.url.includes(window.customPasteSiteUrl)) {
                        const imageUrl = background.url;
                        if (processedImages[imageUrl]) {
                            const imageData = processedImages[imageUrl];
                            editedBlock.attributes.style.background.backgroundImage.url = imageData.url;
                            editedBlock.attributes.style.background.backgroundImage.id = imageData.id;
                        }
                    }

                    // Check the7-blocks svg
                    const dtCrSVGUrl = block.attributes?.imageURL;
                    if (dtCrSVGUrl && !dtCrSVGUrl.includes(window.customPasteSiteUrl)) {
                        if (processedImages[dtCrSVGUrl]) {
                            const imageData = processedImages[dtCrSVGUrl];
                            editedBlock.attributes.imageURL = imageData.url;
                            editedBlock.attributes.imageID = imageData.id;
                        }
                    }

                    return editedBlock;
                }, true); // Pass true for isAsync
                debugInfo.timeEnd('  ↪ Updating blocks with processed images');

                // Print image processing stats
                debugInfo.printStats();

                debugInfo.timeEnd('⚡ Processing pasted content');
                return processedBlocks;
            }

            debugInfo.timeEnd('⚡ Processing pasted content');
            return blocks;
        };

        // Wait for the editor to fully initialize
        let editorReady = false;

        const waitForEditor = () => {
            // Check if the editor is ready by testing if we can select blocks
            try {
                const editor = select('core/block-editor') || select('core/editor');
                editorReady = editor && typeof editor.getBlocks === 'function';
            } catch (e) {
                editorReady = false;
            }

            if (editorReady) {
                // Find the editor container
                const editorContainer = document.querySelector('.editor-styles-wrapper') ||
                    document.querySelector('.block-editor-writing-flow') ||
                    document.querySelector('.block-editor-iframe__body') ||
                    document.querySelector('[name="editor-canvas"]') ||
                    document.querySelector('.editor-writing-flow');

                if (editorContainer) {
                    console.log('Editor detected, attaching paste handler');
                    setupPasteHandler(editorContainer);
                    return true;
                }
            }

            return false;
        };

        // Set up the paste event handler on the editor container
        const setupPasteHandler = (editorContainer) => {
            // If editorContainer is an iframe, attach listener to its contentDocument
            const target = (editorContainer.tagName && editorContainer.tagName.toLowerCase() === 'iframe' && editorContainer.contentDocument) ? editorContainer.contentDocument : editorContainer;
            target.addEventListener('paste', async (event) => {
                // Check if we're pasting in an input field or non-editor area
                let activeElement = null;
                try {
                    activeElement = target.activeElement || document.activeElement;
                } catch (e) {
                    console.log('Error accessing activeElement:', e);
                }
                const isTextField = activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA');

                if (isTextField) {
                    console.log('Paste in text field, not intercepting');
                    return;
                }

                console.log('Intercepting paste event in editor');

                const clipboardData = event.clipboardData || window.clipboardData;
                let html = clipboardData.getData('text/html');
                const text = clipboardData.getData('text/plain');
                const the7ImportMarker = '<!-- the7-import -->';

                if ((html && html.includes(the7ImportMarker)) || (text && text.includes(the7ImportMarker))) {
                    event.preventDefault();
                } else {
                    return;
                }

                try {
                    let processedContent;

                    // Add spinner to the event.target element.
                    const spinner = document.createElement('div');
                    spinner.className = 'the7-spinner spinner is-active';
                    event.target.innerHTML = spinner.outerHTML;

                    if (text) {
                        processedContent = await processPastedContent(text.replace(the7ImportMarker, '').trim());
                    } else {
                        processedContent = await processPastedContent(html.replace(the7ImportMarker, '').trim());
                    }

                    // Remove spinner
                    const spinnerElement = event.target.querySelector('.the7-spinner');
                    if (spinnerElement) {
                        spinnerElement.remove();
                    }

                    window.triggerSyntheticPasteBlocks(event.target, processedContent);
                } catch (error) {
                    console.error('Error processing pasted content:', error);
                }
            }, {capture: true});
        };

        // Check for editor immediately and set up a fallback interval
        if (!waitForEditor()) {
            console.log('Editor not ready, waiting...');

            // Set up an interval to check for the editor
            const editorCheckInterval = setInterval(() => {
                if (waitForEditor()) {
                    console.log('Editor found after interval check');
                    clearInterval(editorCheckInterval);
                }
            }, 500);

            // Clear interval after 30 seconds to prevent infinite checking
            setTimeout(() => {
                clearInterval(editorCheckInterval);
                console.log('Stopped checking for editor after timeout');
            }, 30000);
        }
    });

    // Log that the plugin is loaded
    console.log('Custom paste handler plugin loaded');

    /**
     * Helper to dispatch a paste event on the correct target for iframes
     */
    function dispatchPasteEvent(target, event) {
        target.dispatchEvent(event);
    }

    /**
     * Triggers a synthetic paste event with predefined clipboard data
     * @param {Element} target - The DOM element to dispatch the event on (defaults to window)
     * @param {string} text - The text to include in the clipboard (defaults to "Bingo!!!")
     */
    window.triggerSyntheticPaste = function (target = window, text = "Bingo!!!") {
        // Create a new clipboard event of type 'paste'
        const pasteEvent = new ClipboardEvent('paste', {
            bubbles: true,
            cancelable: true,
            clipboardData: new DataTransfer()
        });

        // Set the clipboard data
        pasteEvent.clipboardData.setData('text/plain', text);

        // Dispatch the event using helper
        dispatchPasteEvent(target, pasteEvent);

        console.log(`Synthetic paste event triggered with text: "${text}"`);
    };

    /**
     * Triggers a synthetic paste event with predefined clipboard data
     * @param {Element} target - The DOM element to dispatch the event on (defaults to window)
     * @param {Array} blocks - The blocks to include in the clipboard (defaults to an empty array)
     */
    window.triggerSyntheticPasteBlocks = function (target = window, blocks = []) {
        // Create a new clipboard event of type 'paste'
        const pasteEvent = new ClipboardEvent('paste', {
            bubbles: true,
            cancelable: true,
            clipboardData: new DataTransfer()
        });

        setClipboardBlocks(pasteEvent, blocks);

        // Dispatch the event using helper
        dispatchPasteEvent(target, pasteEvent);

        console.log(`Synthetic paste event triggered with text: "${pasteEvent.clipboardData.getData('text/plain')}"`);
    };

    function setClipboardBlocks(event, blocks) {
        const serialized = serialize(blocks);

        event.clipboardData.setData('text/plain', toPlainText(serialized));
        event.clipboardData.setData('text/html', serialized);
    }

    /**
     * Given a string of HTML representing serialized blocks, returns the plain
     * text extracted after stripping the HTML of any tags and fixing line breaks.
     *
     * @param {string} html Serialized blocks.
     * @return {string} The plain-text content with any html removed.
     */
    function toPlainText(html) {
        // Manually handle BR tags as line breaks prior to `stripHTML` call
        html = html.replace(/<br>/g, '\n');

        const plainText = stripHTML(html).trim();

        // Merge any consecutive line breaks
        return plainText.replace(/\n\n+/g, '\n\n');
    }

    // Add debug information utility
    const debugInfo = {
        enabled: window.customPasteConfig?.debug || false, // Use WordPress debug setting
        imageStats: {
            total: 0,
            fromCache: 0,
            newlyDownloaded: 0,
            failed: 0,
            batchesProcessed: 0
        },
        log: function(...args) {
            if (this.enabled) {
                console.log(...args);
            }
        },
        time: function(label) {
            if (this.enabled) {
                console.time(label);
            }
        },
        timeEnd: function(label) {
            if (this.enabled) {
                console.timeEnd(label);
            }
        },
        resetStats: function() {
            this.imageStats = {
                total: 0,
                fromCache: 0,
                newlyDownloaded: 0,
                failed: 0,
                batchesProcessed: 0
            };
        },
        printStats: function() {
            if (this.enabled) {
                console.log('🖼️ Image Processing Stats:');
                console.log(`  Total images processed: ${this.imageStats.total}`);
                console.log(`  Images from cache: ${this.imageStats.fromCache}`);
                console.log(`  Images newly downloaded: ${this.imageStats.newlyDownloaded}`);
                console.log(`  Failed images: ${this.imageStats.failed}`);
                console.log(`  Batch requests: ${this.imageStats.batchesProcessed}`);

                if (this.imageStats.total > 0) {
                    const cacheHitRate = (this.imageStats.fromCache / this.imageStats.total * 100).toFixed(1);
                    console.log(`  Cache hit rate: ${cacheHitRate}%`);
                }
            }
        }
    };

})(window.wp);
