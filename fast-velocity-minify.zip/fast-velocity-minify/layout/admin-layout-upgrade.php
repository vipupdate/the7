<?php if( $active_tab == 'upgrade' ) { ?>

<div class="fvm-wrapper">

<h2 class="title">Upgrade Your Speed</h2>
<h3 class="fvm-bold-green">Would you like to improve your speed and google scores further?</h3>



</div>
<?php 
}
