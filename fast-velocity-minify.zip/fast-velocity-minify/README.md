# fast-velocity-minify
Official repository for Fast Velocity Minify
https://wordpress.org/plugins/fast-velocity-minify/
